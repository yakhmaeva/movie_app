import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class UIObject:

    def __init__(self, driver, by, locator):
        self.driver = driver
        self.by = by
        self.locator = locator

    def is_clickable(self):

        def is_clickable(driver, by, locator):
            try:
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable((by, locator)))
                return True
            except:
                return False

        return self.exists() and is_clickable(self.driver, self.by, self.locator)

    def wait_to_be_clickable(self, seconds=60, ignore_error=False):

        start = time.time()
        while (time.time() - start) < seconds:
            if self.is_clickable():
                return self
            time.sleep(1)
        if not ignore_error:
            if self.exists():
                raise AssertionError("Locator in the DOM: {} but did not become click-able in {} seconds"
                                     .format(self.locator, seconds))
            raise AssertionError("Locator is not in the DOM and so not click-able: {}".format(self.locator))
        else:
            return self
