from pages.ios.MABottomMenu import IOSMABottomMenu
from pages.ios.MAPopularPage import IOSMAPopularPage
from pages.ios.MAMovieProfilePage import IOSMAMovieProfilePage
from pages.ios.MAFavoritesPage import IOSFavoritesPage

from pages.android.MABottomMenu import AndroidMABottomMenu
from pages.android.MAPopularPage import AndroidMAPopularPage
from pages.android.MAMovieProfilePage import AndroidMAMovieProfilePage
from pages.android.MAFavoritesPage import AndroidFavoritesPage


class Pages:

    def __init__(self, driver):
        self.driver = driver

        desired_cap = {}
        desired_cap['appium:platformName'] = 'iOS'
        desired_cap['appium:platformVersion'] = '15.0'
        desired_cap['appium:deviceName'] = 'iPhone 13'

        # desired_cap['appium:deviceName'] = 'Android Emulator'
        # desired_cap['platformName'] = 'Android'
        # desired_cap['appium:platformVersion'] = '11'

        self.driver = driver.Remote("http://127.0.0.1:4723/wd/hub", desired_cap)

        self.ios_bottom_menu = IOSMABottomMenu(self.driver)
        self.ios_popular_page = IOSMAPopularPage(self.driver)
        self.ios_movie_profile_page = IOSMAMovieProfilePage(self.driver)
        self.ios_favorites_page = IOSFavoritesPage(self.driver)

        self.android_bottom_menu = AndroidMain(self.driver)
        self.android_popular_page = AndroidMarketplace(self.driver)
        self.android_movie_profile_page = AndroidPreOwnedInventory(self.driver)
        self.android_favorites_page = AndroidFavoritesPage(self.driver)
