import logging
import time
import os

import allure
from allure_commons.types import AttachmentType
from selenium.webdriver.common.by import By
from utils.UIObject import UIObject

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AndroidMAMovieProfilePage:

    def __init__(self, driver):
        self.driver = driver

        self.movie_profile_page_title = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.favorites_star = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.favorites_star_selected = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_title = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_generes = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_large_image = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_small_image = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_rating = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_description = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.similar_movies_title = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.similar_movies_avatar = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.ok_button = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")

    @allure.step("Click favorites star to add to favorites")
    def click_favorites_star_to_add_to_favorites(self):
        assert self.favorites_star.wait_to_be_clickable()
        self.favorites_star.click()
        assert self.favorites_star_selected.is_displayed()
        
    ## TBD: we will also need 2 functions to navigate to movie avatar 
    ##      1. by name
    ##      2. by index

    @allure.step("Navigate to similar movie avatar by name")
    def navigate_to_similar_movie_avatar_by_name(self, name):
        ### name: string
        ### tbd
        ###
        assert avatar_movie_name == name

    @allure.step("Navigate to similar movie avatar index")
    def navigate_to_similar_movie_avatar_by_index(self, index):
        ### index: int
        ### tbd
        ###
        assert avatar_movie_index == index

    @allure.step("Click OK button")
    def click_ok_button(self):
        logger.info("Click OK button")
        assert self.ok_button.wait_to_appear()
        self.ok_button.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)
        