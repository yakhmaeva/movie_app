import logging
import time

import allure
from allure_commons.types import AttachmentType
from selenium.webdriver.common.by import By
from utils.UIObject import UIObject


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class IOSMAFavoritesPage:

    def __init__(self, driver):
        self.driver = driver

        self.movie_avatar = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")

    
    ## TBD: we will also need 2 functions to navigate to movie avatar 
    ##      1. by name
    ##      2. by index

    @allure.step("Navigate to movie avatar by name")
    def navigate_to_movie_avatar_by_name(self, name):
        ### name: string
        ### tbd
        ###
        assert avatar_movie_name == name

    @allure.step("Navigate to movie avatar")
    def navigate_to_movie_avatar_by_index(self, index):
        ### index: int
        ### tbd
        ###
        assert avatar_movie_index == index
