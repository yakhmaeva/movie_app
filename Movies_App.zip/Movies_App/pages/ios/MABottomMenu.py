import logging
import time
import os

import allure
from allure_commons.types import AttachmentType
from selenium.webdriver.common.by import By
from utils.UIObject import UIObject

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class IOSMABottomMenu:

    def __init__(self, driver):
        self.driver = driver

        self.popular_tab = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.favorites_tab = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")

    @allure.step("Close app")
    def teardown(self):
        logger.info("Close app")
        self.driver.quit()

    @allure.step("Click popular tab")
    def click_popular_tab(self):
        logger.info("Click popular tab")
        assert self.popular_tab.wait_to_appear()
        self.popular_tab.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

    @allure.step("Click favorites tab")
    def click_favorites_tab(self):
        logger.info("Click favorites tab")
        assert self.favorites_tab.wait_to_appear()
        self.favorites_tab.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)
