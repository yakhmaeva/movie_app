import logging
import time
import os

import allure
from allure_commons.types import AttachmentType
from selenium.webdriver.common.by import By
from utils.UIObject import UIObject

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class IOSMAPopularPage:

    def __init__(self, driver):
        self.driver = driver

        self.popular_header = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.sort_button = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.sort_clear = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.sort_by_title = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.sort_by_release_date = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.cancel_sort = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")
        self.movie_avatar = UIObject(self.driver, By.XPATH, "//tagname[@attribute='value']")


    @allure.step("Close app")
    def teardown(self):
        logger.info("Close app")
        self.driver.quit()

    @allure.step("Click Sort button and then Clear")
    def click_sort_clear(self):
        assert self.sort_button.wait_to_be_clickable()
        self.sort_button.click()
        assert self.sort_clear.wait_to_be_clickable()
        self.sort_clear.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

    @allure.step("Click Sort button and then Sort it by Title")
    def click_sort_by_title(self):
        assert self.sort_button.wait_to_be_clickable()
        self.sort_button.click()
        assert self.sort_by_title.wait_to_be_clickable()
        self.sort_by_title.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

    @allure.step("Click Sort button and then Sort it by Release date")
    def click_sort_by_release_date(self):
        assert self.sort_button.wait_to_be_clickable()
        self.sort_button.click()
        assert self.sort_by_release_date.wait_to_be_clickable()
        self.sort_by_release_date.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

    @allure.step("Click Sort button and then Cancel sort")
    def click_cancel_sort(self):
        assert self.sort_button.wait_to_be_clickable()
        self.sort_button.click()
        assert self.cancel_sort.wait_to_be_clickable()
        self.cancel_sort.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

    ## TBD: we will also need 2 functions to navigate to movie avatar 
    ##      1. by name
    ##      2. by index

    @allure.step("Navigate to movie avatar by name")
    def navigate_to_movie_avatar_by_name(self, name):
        ### name: string
        ### tbd
        ###
        assert avatar_movie_name == name

    @allure.step("Navigate to movie avatar")
    def navigate_to_movie_avatar_by_index(self, index):
        ### index: int
        ### tbd
        ###
        assert avatar_movie_index == index

    @allure.step("Click on Movie avatar")
    def click_movie_avatar(self):
        assert self.movie_avatar.wait_to_be_clickable()
        self.movie_avatar.click()
        time.sleep(5)
        allure.attach(self.driver.get_screenshot_as_png(), name="Screenshot", attachment_type=AttachmentType.PNG)

