import pytest
from utils.Pages import Pages
from appium import webdriver


@pytest.mark.usefixtures('test_init')
class TestVerifyMovieAddedToFavorites:

    @pytest.fixture(scope="function")
    def test_init(self):
        self.movies_app.open()
        yield
        self.movies_app.close()

    @pytest.mark.tc01
    def test_tc01_Verify_Movie_Can_be_Added_to_Favorites(self, test_init):
        """
        Test Case: TC01 
        Test Steps:
        Step 1 - Open movie app
        Step 2 - Click the movie avatar to open movie profile page
        Step 3 - Click to star "add to favorites" in the top of right corner
        Step 4 - Check favorites tab if the movie is present in the list 
        """

        self.pgs.ios_popular_page.navigate_to_movie_avatar_by_name("Uncharted")
        self.pgs.ios_popular_page.click_movie_avatar()
        self.pgs.ios_movie_profile_page.click_favorites_star_to_add_to_favorites()
        self.pgs.ios_favorites_page.navigate_to_movie_avatar_by_name("Uncharted")
